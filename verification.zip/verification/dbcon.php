
<?php


$conn = mysqli_connect("localhost", "root", "", "verify_db");



?>