

<?php 
$page_title = "Home Page";
include('include/header.php');
include('include/navbar.php');

?>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2>Login and Registration Form</h2>
                <h4>with Email Verification</h4>
            </div>
        </div>
    </div>
</div>


<?php include('include/footer.php');?>


