# email_verification
How to send and verify email with php mailer library
